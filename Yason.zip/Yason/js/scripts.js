// Bean Boutique scripts - vanilla JS only

(function () {
  const body = document.body;
  const page = body.getAttribute("data-page");

  /* Utility helpers */
  const storage = {
    get(key, fallback) {
      try {
        const value = localStorage.getItem(key);
        return value ? JSON.parse(value) : fallback;
      } catch {
        return fallback;
      }
    },
    set(key, value) {
      try {
        localStorage.setItem(key, JSON.stringify(value));
      } catch {
        // ignore
      }
    },
  };

  const session = {
    get(key, fallback) {
      try {
        const value = sessionStorage.getItem(key);
        return value ? JSON.parse(value) : fallback;
      } catch {
        return fallback;
      }
    },
    set(key, value) {
      try {
        sessionStorage.setItem(key, JSON.stringify(value));
      } catch {
        // ignore
      }
    },
  };

  /* Year in footer */
  const yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  /* Navigation toggle */
  const navToggle = document.querySelector(".nav-toggle");
  const nav = document.getElementById("primary-nav");
  if (navToggle && nav) {
    navToggle.addEventListener("click", function () {
      const open = nav.classList.toggle("open");
      navToggle.setAttribute("aria-expanded", open ? "true" : "false");
    });
  }

  /* Dark mode */
  const darkToggle = document.getElementById("dark-mode-toggle");
  const savedTheme = storage.get("bean-theme", "light");
  if (savedTheme === "dark") {
    body.classList.add("dark-mode");
    if (darkToggle) {
      darkToggle.setAttribute("aria-pressed", "true");
    }
  }
  if (darkToggle) {
    darkToggle.addEventListener("click", function () {
      const isDark = body.classList.toggle("dark-mode");
      storage.set("bean-theme", isDark ? "dark" : "light");
      darkToggle.setAttribute("aria-pressed", isDark ? "true" : "false");
    });
  }

  /* Auth modal & simple user accounts */
  const authModal = document.getElementById("auth-modal");
  const authOpenBtn = document.getElementById("login-open-btn");
  const authCloseBtn = document.getElementById("auth-close-btn");
  const loginEmail = document.getElementById("login-email");
  const loginPassword = document.getElementById("login-password");
  const registerEmail = document.getElementById("register-email");
  const registerPassword = document.getElementById("register-password");
  const loginMessage = document.getElementById("login-message");
  const registerMessage = document.getElementById("register-message");

  function openModal(modal) {
    if (!modal) return;
    modal.setAttribute("aria-hidden", "false");
  }

  function closeModal(modal) {
    if (!modal) return;
    modal.setAttribute("aria-hidden", "true");
  }

  if (authOpenBtn && authModal) {
    authOpenBtn.addEventListener("click", function () {
      openModal(authModal);
    });
  }

  if (authCloseBtn && authModal) {
    authCloseBtn.addEventListener("click", function () {
      closeModal(authModal);
    });
  }

  if (authModal) {
    authModal.addEventListener("click", function (e) {
      if (e.target.classList.contains("modal-backdrop")) {
        closeModal(authModal);
      }
    });
  }

  const tabs = document.querySelectorAll(".tab");
  const panels = document.querySelectorAll(".tab-panel");
  if (tabs.length) {
    tabs.forEach(function (tab) {
      tab.addEventListener("click", function () {
        const target = tab.getAttribute("data-tab");
        tabs.forEach(function (t) {
          t.classList.toggle("active", t === tab);
          t.setAttribute("aria-selected", t === tab ? "true" : "false");
        });
        panels.forEach(function (panel) {
          panel.classList.toggle("active", panel.getAttribute("data-panel") === target);
        });
      });
    });
  }

  function getUsers() {
    return storage.get("bean-users", []);
  }

  function saveUsers(users) {
    storage.set("bean-users", users);
  }

  function getCurrentUser() {
    return storage.get("bean-current-user", null);
  }

  function setCurrentUser(email) {
    storage.set("bean-current-user", email);
    updateLoyaltyBar();
  }

  const registerBtn = document.getElementById("register-submit");
  if (registerBtn && registerEmail && registerPassword && registerMessage) {
    registerBtn.addEventListener("click", function () {
      const email = registerEmail.value.trim();
      const pwd = registerPassword.value.trim();
      if (!email || !pwd) {
        registerMessage.textContent = "Please enter email and password.";
        return;
      }
      const users = getUsers();
      if (users.some(function (u) { return u.email === email; })) {
        registerMessage.textContent = "Account already exists. Please login.";
        return;
      }
      users.push({ email: email, password: pwd, points: 120 });
      saveUsers(users);
      setCurrentUser(email);
      registerMessage.textContent = "Account created. You are now logged in.";
    });
  }

  const loginBtn = document.getElementById("login-submit");
  if (loginBtn && loginEmail && loginPassword && loginMessage) {
    loginBtn.addEventListener("click", function () {
      const email = loginEmail.value.trim();
      const pwd = loginPassword.value.trim();
      const users = getUsers();
      const user = users.find(function (u) { return u.email === email && u.password === pwd; });
      if (!user) {
        loginMessage.textContent = "We couldn’t find that account. Try again.";
        return;
      }
      setCurrentUser(email);
      loginMessage.textContent = "Welcome back, " + email + ".";
    });
  }

  /* Newsletter popup (once per session) */
  const newsletterModal = document.getElementById("newsletter-modal");
  const newsletterCloseBtn = document.getElementById("newsletter-close-btn");
  const newsletterForm = document.getElementById("newsletter-form");
  const newsletterMessage = document.getElementById("newsletter-message");
  const hasSeenNewsletter = session.get("bean-newsletter-seen", false);

  if (newsletterModal && !hasSeenNewsletter) {
    setTimeout(function () {
      openModal(newsletterModal);
    }, 1500);
  }

  if (newsletterCloseBtn && newsletterModal) {
    newsletterCloseBtn.addEventListener("click", function () {
      closeModal(newsletterModal);
      session.set("bean-newsletter-seen", true);
    });
  }

  if (newsletterModal) {
    newsletterModal.addEventListener("click", function (e) {
      if (e.target.classList.contains("modal-backdrop")) {
        closeModal(newsletterModal);
        session.set("bean-newsletter-seen", true);
      }
    });
  }

  if (newsletterForm && newsletterMessage) {
    newsletterForm.addEventListener("submit", function (e) {
      e.preventDefault();
      newsletterMessage.textContent = "Thanks for subscribing. Watch your inbox!";
      session.set("bean-newsletter-seen", true);
      setTimeout(function () {
        closeModal(newsletterModal);
      }, 1200);
    });
  }

  /* Cart operations */
  function getCart() {
    return storage.get("bean-cart", []);
  }

  function saveCart(cart) {
    storage.set("bean-cart", cart);
    updateCartCount();
  }

  function updateCartCount() {
    const countSpan = document.getElementById("cart-count");
    if (!countSpan) return;
    const count = getCart().reduce(function (acc, item) {
      return acc + item.quantity;
    }, 0);
    countSpan.textContent = count;
  }

  updateCartCount();

  function addToCartFromButton(btn) {
    const name = btn.getAttribute("data-name");
    const price = parseFloat(btn.getAttribute("data-price") || "0");
    const type = btn.getAttribute("data-type") || "coffee";
    const id = (btn.closest("[data-product-id]") || {}).getAttribute("data-product-id") || name;
    let cart = getCart();
    const existing = cart.find(function (item) { return item.id === id; });
    if (existing) {
      existing.quantity += 1;
    } else {
      cart.push({ id: id, name: name, price: price, quantity: 1, type: type });
    }
    saveCart(cart);
  }

  const addButtons = document.querySelectorAll(".add-to-cart");
  if (addButtons.length) {
    addButtons.forEach(function (btn) {
      btn.addEventListener("click", function () {
        addToCartFromButton(btn);
      });
    });
  }

  /* Cart page rendering */
  function renderCartTable() {
    if (page !== "cart") return;
    const cartBody = document.getElementById("cart-body");
    const cartEmpty = document.getElementById("cart-empty");
    const cartTable = document.getElementById("cart-table");
    const cartTotal = document.getElementById("cart-total");
    if (!cartBody || !cartEmpty || !cartTotal || !cartTable) return;
    const cart = getCart();
    cartBody.innerHTML = "";
    if (!cart.length) {
      cartEmpty.style.display = "block";
      cartTable.style.display = "none";
      cartTotal.textContent = "$0";
      return;
    }
    cartEmpty.style.display = "none";
    cartTable.style.display = "table";
    let total = 0;
    cart.forEach(function (item, index) {
      const tr = document.createElement("tr");
      const subtotal = item.price * item.quantity;
      total += subtotal;
      tr.innerHTML =
        "<td>" + item.name + "</td>" +
        "<td>" + item.type + "</td>" +
        "<td>$" + item.price.toFixed(2) + "</td>" +
        '<td><input type="number" min="1" value="' + item.quantity + '" data-index="' + index + '" class="cart-qty"></td>' +
        "<td>$" + subtotal.toFixed(2) + "</td>" +
        '<td><button type="button" class="btn-ghost cart-remove" data-index="' + index + '">Remove</button></td>';
      cartBody.appendChild(tr);
    });
    cartTotal.textContent = "$" + total.toFixed(2);
  }

  if (page === "cart") {
    renderCartTable();
    const cartBody = document.getElementById("cart-body");
    const checkoutBtn = document.getElementById("checkout-btn");
    const checkoutMessage = document.getElementById("checkout-message");
    if (cartBody) {
      cartBody.addEventListener("input", function (e) {
        if (e.target.classList.contains("cart-qty")) {
          const index = parseInt(e.target.getAttribute("data-index") || "0", 10);
          const qty = Math.max(1, parseInt(e.target.value || "1", 10));
          const cart = getCart();
          if (cart[index]) {
            cart[index].quantity = qty;
            saveCart(cart);
            renderCartTable();
          }
        }
      });
      cartBody.addEventListener("click", function (e) {
        if (e.target.classList.contains("cart-remove")) {
          const index = parseInt(e.target.getAttribute("data-index") || "0", 10);
          let cart = getCart();
          cart.splice(index, 1);
          saveCart(cart);
          renderCartTable();
        }
      });
    }
    if (checkoutBtn && checkoutMessage) {
      checkoutBtn.addEventListener("click", function () {
        const cart = getCart();
        if (!cart.length) {
          checkoutMessage.textContent = "Your cart is empty.";
          return;
        }
        const user = getCurrentUser();
        if (!user) {
          checkoutMessage.textContent = "Please login to complete checkout.";
          return;
        }
        let users = getUsers();
        const idx = users.findIndex(function (u) { return u.email === user; });
        if (idx !== -1) {
          const earned = cart.reduce(function (acc, item) {
            return acc + Math.round(item.price * item.quantity);
          }, 0);
          users[idx].points = (users[idx].points || 0) + earned;
          saveUsers(users);
        }
        storage.set("bean-cart", []);
        updateCartCount();
        renderCartTable();
        checkoutMessage.textContent = "Checkout complete! Your loyalty points have been updated.";
        updateLoyaltyBar(true);
      });
    }
  }

  /* Loyalty bar */
  function updateLoyaltyBar(animate) {
    const fill = document.getElementById("loyalty-fill");
    const text = document.getElementById("loyalty-text");
    if (!fill || !text) return;
    const userEmail = getCurrentUser();
    if (!userEmail) {
      fill.style.width = "0";
      text.textContent = "Sign in to start earning.";
      return;
    }
    const users = getUsers();
    const user = users.find(function (u) { return u.email === userEmail; });
    const points = user && typeof user.points === "number" ? user.points : 0;
    const pct = Math.min(100, (points % 500) / 5); // cycle every 500 points
    fill.style.width = pct + "%";
    if (animate) {
      fill.classList.add("pulse");
      setTimeout(function () { fill.classList.remove("pulse"); }, 700);
    }
    text.textContent = "You have " + points + " points. " + (500 - (points % 500)) + " to your next reward.";
  }

  updateLoyaltyBar(false);

  /* Live chat simulated responses */
  const chatToggle = document.getElementById("chat-toggle");
  const chatWindow = document.getElementById("chat-window");
  const chatClose = document.getElementById("chat-close");
  const chatBody = document.getElementById("chat-body");
  const chatForm = document.getElementById("chat-form");
  const chatInput = document.getElementById("chat-input");

  function appendChatMessage(text, sender) {
    if (!chatBody) return;
    const div = document.createElement("div");
    div.className = "chat-message " + (sender || "bot");
    div.textContent = text;
    chatBody.appendChild(div);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  if (chatToggle && chatWindow) {
    chatToggle.addEventListener("click", function () {
      chatWindow.classList.toggle("open");
    });
  }
  if (chatClose && chatWindow) {
    chatClose.addEventListener("click", function () {
      chatWindow.classList.remove("open");
    });
  }
  if (chatForm && chatInput) {
    chatForm.addEventListener("submit", function (e) {
      e.preventDefault();
      const text = chatInput.value.trim();
      if (!text) return;
      appendChatMessage(text, "user");
      chatInput.value = "";
      setTimeout(function () {
        const lower = text.toLowerCase();
        if (lower.indexOf("espresso") !== -1) {
          appendChatMessage("Our House Espresso is rich and chocolatey—perfect with milk.", "bot");
        } else if (lower.indexOf("workshop") !== -1 || lower.indexOf("event") !== -1) {
          appendChatMessage("Check the Events & Workshops page to see upcoming cuppings and latte art jams.", "bot");
        } else if (lower.indexOf("hours") !== -1) {
          appendChatMessage("We’re open every day from 7am to 7pm.", "bot");
        } else {
          appendChatMessage("Thanks for the message! A human barista will get back to you soon.", "bot");
        }
      }, 800);
    });
  }

  /* Coffee filters and sorting */
  if (page === "coffee") {
    const searchInput = document.getElementById("coffee-search");
    const filterMethod = document.getElementById("filter-method");
    const filterOrigin = document.getElementById("filter-origin");
    const sortSelect = document.getElementById("sort-coffee");
    const grid = document.getElementById("coffee-grid");
    if (grid && searchInput && filterMethod && filterOrigin && sortSelect) {
      const items = Array.prototype.slice.call(grid.querySelectorAll(".product-card"));

      function applyFilters() {
        const term = searchInput.value.trim().toLowerCase();
        const method = filterMethod.value;
        const origin = filterOrigin.value;
        items.forEach(function (card) {
          const notes = (card.getAttribute("data-notes") || "").toLowerCase();
          const thisMethod = card.getAttribute("data-method") || "";
          const thisOrigin = card.getAttribute("data-origin") || "";
          let visible = true;
          if (term && notes.indexOf(term) === -1 && card.textContent.toLowerCase().indexOf(term) === -1) {
            visible = false;
          }
          if (method && thisMethod !== method) visible = false;
          if (origin && thisOrigin !== origin) visible = false;
          card.style.display = visible ? "" : "none";
        });
      }

      function applySort() {
        const mode = sortSelect.value;
        if (mode === "default") return;
        const sorted = items.slice().sort(function (a, b) {
          const priceA = parseFloat(a.getAttribute("data-price") || "0");
          const priceB = parseFloat(b.getAttribute("data-price") || "0");
          const ratingA = parseFloat(a.getAttribute("data-rating") || "0");
          const ratingB = parseFloat(b.getAttribute("data-rating") || "0");
          if (mode === "price-asc") return priceA - priceB;
          if (mode === "price-desc") return priceB - priceA;
          if (mode === "rating-desc") return ratingB - ratingA;
          return 0;
        });
        sorted.forEach(function (card) {
          grid.appendChild(card);
        });
      }

      searchInput.addEventListener("input", applyFilters);
      filterMethod.addEventListener("change", applyFilters);
      filterOrigin.addEventListener("change", applyFilters);
      sortSelect.addEventListener("change", function () {
        applySort();
        applyFilters();
      });
    }
  }

  /* Brewing simulator drag & drop */
  if (page === "equipment") {
    const ingredients = document.querySelectorAll(".ingredient");
    const dropzone = document.getElementById("brew-dropzone");
    const result = document.getElementById("brew-result");
    const collected = [];

    if (dropzone && result && ingredients.length) {
      ingredients.forEach(function (item) {
        item.addEventListener("dragstart", function (e) {
          e.dataTransfer.setData("text/plain", item.getAttribute("data-ingredient"));
          dropzone.classList.add("active");
        });
        item.addEventListener("keydown", function (e) {
          if (e.key === "Enter" || e.key === " ") {
            e.preventDefault();
            const ing = item.getAttribute("data-ingredient");
            if (collected.indexOf(ing) === -1) collected.push(ing);
            updateBrewResult();
          }
        });
      });

      dropzone.addEventListener("dragover", function (e) {
        e.preventDefault();
      });
      dropzone.addEventListener("dragleave", function () {
        dropzone.classList.remove("active");
      });
      dropzone.addEventListener("drop", function (e) {
        e.preventDefault();
        dropzone.classList.remove("active");
        const ing = e.dataTransfer.getData("text/plain");
        if (ing && collected.indexOf(ing) === -1) collected.push(ing);
        updateBrewResult();
      });

      function updateBrewResult() {
        if (collected.length < 3) {
          result.textContent = "You added " + collected.join(", ") + ". Add at least " + (3 - collected.length) + " more ingredients.";
        } else {
          result.textContent = "Brew complete! You crafted a balanced cup with " + collected.join(", ") + ".";
        }
      }
    }
  }

  /* Events form */
  if (page === "events") {
    const eventForm = document.getElementById("event-form");
    const eventMessage = document.getElementById("event-message");
    const firstName = document.getElementById("event-first-name");
    const lastName = document.getElementById("event-last-name");
    const email = document.getElementById("event-email");
    const eventSelect = document.getElementById("event-select");
    const socialGrid = document.getElementById("social-grid");

    if (eventForm && eventMessage && firstName && lastName && email && eventSelect) {
      eventForm.addEventListener("submit", function (e) {
        e.preventDefault();
        if (!firstName.value || !lastName.value || !email.value || !eventSelect.value) {
          eventMessage.textContent = "Please fill in all required fields.";
          return;
        }
        eventMessage.textContent = "Thanks, " + firstName.value + "! You’re registered for " + eventSelect.value + ".";
        eventForm.reset();
      });
    }

    if (socialGrid) {
      const posts = [
        {
          handle: "@beanboutique",
          text: "Espresso shots dialed in for the morning rush.",
          img: "https://images.pexels.com/photos/324028/pexels-photo-324028.jpeg",
        },
        {
          handle: "@latteartclub",
          text: "Rosettas for days at our Latte Art Jam.",
          img: "https://images.pexels.com/photos/302896/pexels-photo-302896.jpeg",
        },
        {
          handle: "@homebrewers",
          text: "Sunday cupping flight ready to go.",
          img: "https://images.pexels.com/photos/373888/pexels-photo-373888.jpeg",
        },
      ];
      posts.forEach(function (post) {
        const div = document.createElement("article");
        div.className = "social-card";
        div.innerHTML =
          '<img src="' + post.img + '" alt="Social post image">' +
          "<strong>" + post.handle + "</strong>" +
          "<p>" + post.text + "</p>";
        socialGrid.appendChild(div);
      });
    }
  }

  /* Testimonials carousel on home */
  if (page === "home") {
    const slides = document.querySelectorAll(".testimonial-slide");
    if (slides.length > 1) {
      let index = 0;
      setInterval(function () {
        slides[index].classList.remove("active");
        index = (index + 1) % slides.length;
        slides[index].classList.add("active");
      }, 5000);
    }
  }
})();


